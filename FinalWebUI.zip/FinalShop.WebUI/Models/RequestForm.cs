﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinalShop.WebUI.Models
{
    public class RequestForm
    {
        public int ReqID { get; set; }
        
        public string ReqItem { get; set; }
        
        public string ReqResaon { get; set; }
    }
}