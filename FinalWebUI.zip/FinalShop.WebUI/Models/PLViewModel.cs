﻿using System.Collections.Generic;
using FinalShop.Domain.Entities;

namespace FinalShop.WebUI.Models
{
    public class PLViewModel
    {
        public IEnumerable<Product> Products { get; set; }
        public PagingInfo PagingInfo { get; set; }
        public string CurrentCategory { get; set; }
    }
}