﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FinalShop.Domain.Entities;

namespace FinalShop.WebUI.Models
{
    public class EventListStlye
    {
      
    }
}