﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FinalShop.Domain.Entities;

namespace FinalShop.WebUI.Models
{
    public class CartIndexView
    {
        public Cart cart { get; set; }
        public string ReturnUrl { get; set; }
    }
}