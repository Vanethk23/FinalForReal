﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FinalShop.WebUI.Models;

namespace FinalShop.WebUI.Models
{
    public class MultTable
    {
       public IEnumerable<Event> Events { get; set; }
        public IEnumerable<Rent> Rents { get; set; }
    }
}