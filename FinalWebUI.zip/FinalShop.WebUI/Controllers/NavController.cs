﻿using System.Web.Mvc;
using System.Collections.Generic;
using FinalShop.Domain.Abstruct;
using System.Linq;

namespace FinalShop.WebUI.Controllers
{
    public class NavController : Controller
    {
        private IPR resp;
        public NavController(IPR repo)
        {
            resp = repo;
        }
        public PartialViewResult Menu(string categories = null)
        {
            ViewBag.SelectedCategory = categories;
            IEnumerable<string> categorys = resp.Products.Select(x => x.ProductCategory).Distinct().OrderBy(x => x);

            return PartialView(categorys);
        }
    }
}