﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FinalShop.Domain.Abstruct;
using FinalShop.WebUI.Models;

namespace FinalShop.WebUI.Controllers
{
    public class EventController : Controller
    {
      

      
         ConnectionVSCEntities Enti = new ConnectionVSCEntities();

        public ActionResult Cal()
        {

            /* var Event = from e in Enti.Events
                         select e;*/
             MultTable Twotable = new MultTable();
            Twotable.Events = Enti.Events.ToList();
            Twotable.Rents = Enti.Rents.ToList();
            
        

            return View(Twotable);
        }
        
    }
    
}