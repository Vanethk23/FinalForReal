﻿using System.Linq;
using System.Web;
using System.Web.Mvc;
using FinalShop.Domain.Abstruct;
using FinalShop.Domain.Entities;
using FinalShop.WebUI.Models;

namespace FinalShop.WebUI.Controllers
{
    public class CartController : Controller
    {
        private IPR reps;
       
        public CartController (IPR repos)
        {
            reps = repos;
        }
        private Cart GetCart()
        {
            Cart cart = (Cart)Session["Cart"];
            if (cart == null)
            {
                cart = new Cart();
                Session["Cart"] = cart;
            }
            return cart;

        }
        public RedirectToRouteResult AddToCart(Cart cart,int productID, string returnUrl)
        {
            Product product = reps.Products.FirstOrDefault(p => p.ProductID == productID);
            if (product != null)
            {
               cart.AddItem(product, 1);
            }
            return RedirectToAction("Index", new { returnUrl});
        }
        public RedirectToRouteResult RemovefromCart(Cart cart,int productID, string returnUrl)
        {
            Product product = reps.Products.FirstOrDefault(p => p.ProductID == productID);
            if (product != null)
            {
               cart.RemovePro(product);
            }
            return RedirectToAction("Index", new { returnUrl });
        }
        public ViewResult Index(Cart cart,string returnUrl)
        {
            return View(new CartIndexView
            {

                ReturnUrl = returnUrl,
               cart = cart
            });
        }
    }
}