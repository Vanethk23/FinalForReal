﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FinalShop.Domain.Abstruct;
using FinalShop.WebUI.Models;
namespace FinalShop.WebUI.Controllers
{
    public class AboutController : Controller
    {
        
        public ActionResult AboutUs()
        {
          
            return View();
        }
        [HttpPost]
        public ActionResult AboutUs(Requst quest)
        {

            ConnectionVSCEntities Enti = new ConnectionVSCEntities();
            try
            {
                /*Requst nquest = new Requst();
                nquest.ReqItem = quest.ReqItem;
                nquest.ReqResaon = quest.ReqResaon;*/
                Enti.Requsts.Add(quest);
                Enti.SaveChanges();
               
                return RedirectToAction("AboutUs");
            }
            catch
            {
                return View();
            }
               
        }



    }
}