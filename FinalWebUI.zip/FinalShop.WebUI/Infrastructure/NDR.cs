﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Ninject;
using Moq;
using FinalShop.Domain.Abstruct;
using FinalShop.Domain.Concrete;
using FinalShop.Domain.Entities;

namespace FinalShop.WebUI.Infrastructure
{
    public class NDR : IDependencyResolver
    {
        private IKernel myKer;
        public NDR(IKernel kerPar)
        {
            myKer = kerPar;
            AddBindings();
        }
        public object GetService(Type serviceType)
        {
            return myKer.TryGet(serviceType);
        }
        public IEnumerable<object> GetServices(Type serviceType)
        {
            return myKer.GetAll(serviceType);
        }
        private void AddBindings()
        {
            myKer.Bind<IPR>().To<EFProRes>();
        }
    }
    
}