﻿using System;
using System.Text;
using System.Web.Mvc;
using FinalShop.WebUI.Models;

namespace FinalShop.WebUI.HtmlHelpers
{
    public static class PagingHelper
    {
        public static MvcHtmlString PagerLinks(this HtmlHelper html, PagingInfo pagingInfo, Func<int,string> pageUrl)
        {
            StringBuilder result = new StringBuilder();
            for (int i = 1; i <= pagingInfo.TotalPages; i++)
            {
                TagBuilder tags = new TagBuilder("a");
                tags.MergeAttribute("href", pageUrl(i));
                tags.InnerHtml = i.ToString();
                if (i == pagingInfo.CurrentPage)
                {
                    tags.AddCssClass("selected");
                    tags.AddCssClass("btn-primary");
                }
                tags.AddCssClass("btn btn-default");
                result.Append(tags.ToString());
            }
            return MvcHtmlString.Create(result.ToString());
        }
    }
}