﻿using System;
using System.Collections.Generic;
using FinalShop.Domain.Entities;

namespace FinalShop.Domain.Abstruct
{
    public interface IPR
    {
        IEnumerable<Product> Products { get; }

        
    }
}
