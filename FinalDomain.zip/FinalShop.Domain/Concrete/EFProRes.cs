﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FinalShop.Domain.Abstruct;
using FinalShop.Domain.Entities;

namespace FinalShop.Domain.Concrete
{
    public class EFProRes : IPR
    {
        private EFDbCon context = new EFDbCon();
        public IEnumerable<Product> Products
        {
            get { return context.Products; }
        }
  
       
    }
}
