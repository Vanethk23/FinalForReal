﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalShop.Domain.Entities
{
    public class CartLine
    {
        public Product Product { get; set; }
        public int Qty { get; set; }
    }

    public class Cart
    {
        private List<CartLine> LineColletcion = new List<CartLine>();

        public IEnumerable<CartLine> Lines
        {
            get { return LineColletcion; }
        }
        public void AddItem(Product myPro, int myQty)
        {
            CartLine line = LineColletcion.Where(p => p.Product.ProductID == myPro.ProductID).FirstOrDefault();

            if (line == null)
            {
                LineColletcion.Add(new CartLine
                {
                    Product = myPro,
                    Qty = myQty
                });
            }
            else {
                line.Qty += myQty;
            }
        }
        public void RemovePro(Product myPro)
        {
            LineColletcion.RemoveAll(l => l.Product.ProductID == myPro.ProductID);
        }
        public decimal ComToVal()
        {
            return LineColletcion.Sum(e => e.Product.ProductPrice * e.Qty);
        }
        public void Clear()
        {
            LineColletcion.Clear();
        }

    }
}

