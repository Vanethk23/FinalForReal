﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalShop.Domain.Entities
{
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string ProductDis { get; set; }
        public string ProductCategory { get; set; }
        public int ProductQty { get; set; }
        public decimal ProductPrice { get; set; }
    }
}
